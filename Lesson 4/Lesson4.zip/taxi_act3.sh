#!/usr/bin/env bash

# Calculates the higest taxi fare per minute


# get a temp file name for the fares
temp_file_fares=temp${RANDOM}

# The 5th column of the file is the fare in decimal format
# Extract it and split it on the '.' character, to get the integral and decimal parts
# Also include the 6th column that is the trip duration in seconds
cut -d, -f5,6 $1 | cut -d'.' --output-delimiter ' ' -f1-3 >$temp_file_fares


# reads the string in $line and extracts the fare value
# value is stored in $fare
# Multiply it by 100 for precision when we divide later
function get_fare_times_100()
{
  int=${line[0]}
  dec=${line[1]}
  dec_len=${#line[1]}
  
  [[ dec_len -eq 0 ]] && fare=$(( 100 * (10#${int} * 100) ))
  [[ dec_len -eq 1 ]] && fare=$(( 100 * (10#${int} * 100 + 10#${dec} * 10) ))
  [[ dec_len -eq 2 ]] && fare=$(( 100 * (10#${int} * 100 + 10#${dec}) ))
}


# read each line of the temp file
# format has XX YY,ZZ
# where XX and YY are the price values and ZZ is the duration
# We need to split on both space and comma to parse it
IFS=', '

# this will hold the known maximum fare per unit time
max=0

# this will hold the line number of that max data
line_no=0

# Current line
count=1

while read -a line
do
  get_fare_times_100
  duration=${line[2]}
  
  # ignore durations that are shorter than 30 seconds
  if (( duration > 30 )) 
  then
    cost=$(( fare / duration ))  
    (( cost > max )) && max=$cost && line_no=$count
  fi
  
  (( ++count ))
  
done <$temp_file_fares

# Remember that max has units of "1/100 cents" per second, so the conversion factor to $/minute is 60/10000
echo -n "Higest fare per minute is: " 
echo -n $(bc <<< "scale=2; $max*60/10000") 
echo '$'
echo "Line: " $line_no


rm "$temp_file_fares"

