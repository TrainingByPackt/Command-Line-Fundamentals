#!/usr/bin/env bash


# get a temp file name
temp_file=temp${RANDOM}

cut -d, -f5 $1 | cut -d'.' --output-delimiter ' ' -f1,2 >$temp_file

# read each line of the CSV
total_fare=0
count=0
IFS=' '

while read -a line
do
  int=${line[0]}
  dec=${line[1]}
  dec_len=${#line[1]}
  
  [[ dec_len -eq 0 ]] && fare=$(( 10#${int} * 100 ))
  [[ dec_len -eq 1 ]] && fare=$(( 10#${int} * 100 + 10#${dec} * 10))
  [[ dec_len -eq 2 ]] && fare=$(( 10#${int} * 100 + 10#${dec} ))

  total_fare=$(( fare + total_fare ))  
  (( count++ ))
  
done <$temp_file

echo -n "Average fare is: " 
echo -n $(bc <<< "scale=2; ($total_fare / $count) / 100") 
echo '$'

rm "$temp_file"
