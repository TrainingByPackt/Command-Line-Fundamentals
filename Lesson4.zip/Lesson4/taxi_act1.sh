#!/usr/bin/env bash

# get a temp file name for teh fares and the distances
temp_file_fares=temp${RANDOM}
temp_file_dists=temp${RANDOM}

# The 5th column of the file is the fare in decimal format
# Extract it and split it on the '.' character, to get the integral and decimal parts
cut -d, -f5 $1 | cut -d'.' --output-delimiter ' ' -f1,2 >$temp_file_fares

# Extract the 4th column which has the distance in miles as decimal format
# Since the field has a two digits of precision, we can just remove the '.' to get the distance in units of 1/100 of a mile
cut -d, -f4 < $1 | tr -d '.' >$temp_file_dists

# reads the string in $line and extracts the fare value (in cents)
# value is stored in $fare
function get_fare()
{
  int=${line[0]}
  dec=${line[1]}
  dec_len=${#line[1]}
  
  [[ dec_len -eq 0 ]] && fare=$(( 10#${int} * 100 ))
  [[ dec_len -eq 1 ]] && fare=$(( 10#${int} * 100 + 10#${dec} * 10))
  [[ dec_len -eq 2 ]] && fare=$(( 10#${int} * 100 + 10#${dec} ))
}


# read each line of the fares file and total it
IFS=' '
total_fare=0
while read -a line
do
  # Get the fare and add it to the total
  get_fare
  (( total_fare += fare ))
done <$temp_file_fares


# read each line of the distances file and total it
total_dist=0
while read -a line
do
  dist=10#${line[0]}
  (( total_dist += dist ))
done <$temp_file_dists


echo -n "Average fare per mile is: " 
echo -n $(bc <<< "scale=2; $total_fare / $total_dist ") 
echo '$'

rm "$temp_file_fares"
rm "$temp_file_dists"

